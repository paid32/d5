#include <bits/stdc++.h>
using namespace std;
int N;

// function for printing the solution
void printSol(vector<vector<int>> board)
{
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
            cout << board[i][j] << " ";
        cout << "\n";
    }
}

// function to check whether the position is safe or not
bool isSafe(vector<vector<int>> &board, int row, int col)
{
    int i, j;
    for (i = 0; i < col; i++)
        if (board[row][i])
            return false;
    for (i = row, j = col; i >= 0 && j >= 0; i--, j--)
        if (board[i][j])
            return false;
    for (i = row, j = col; j >= 0 && i < N; i++, j--)
        if (board[i][j])
            return false;
    return true;
}

// Recursive function to solve N-queen Problem
bool solve(vector<vector<int>> &board, int col)
{
    // base Case : If all Queens are placed
    if (col >= N)
        return true;

    /* Consider this Column and move in all rows one by one */
    for (int i = 0; i < N; i++)
    {
        if (isSafe(board, i, col))
        {
            board[i][col] = 1; // placing the Queen in board[i][col]

            /* recur to place rest of the queens */
            if (solve(board, col + 1))
                return true;

            // Backtracking
            board[i][col] = 0; // removing the Queen from board[i][col]
        }
    }

    return false;
}

int main()
{
    // Taking input from the user
    cout << "Enter the no of rows for the square Board : ";
    cin >> N;

    // board of size N*N
    vector<vector<int>> board(N, vector<int>(N, 0));

    bool ans = solve(board, 0);

    if (ans == true)
        printSol(board); // printing the solution Board
    else
        cout << "Solution Does not Exist\n";
}